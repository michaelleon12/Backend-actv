const { DataTypes } = require('sequelize');
const sequelize = require('../conections');


const Materias = sequelize.define('Materias', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    name: {
        type: DataTypes.STRING
    },
})

module.exports = Materias