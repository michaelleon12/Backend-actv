const { DataTypes } = require('sequelize');
const sequelize = require('../conections')

const Eventos = sequelize.define('Eventos', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    title: {
        type: DataTypes.STRING
    },
    date:{
        type: DataTypes.DATEONLY
    },
})

module.exports = Eventos