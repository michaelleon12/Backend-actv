const { DataTypes } = require('sequelize');
const sequelize = require('../conections')

const Eventos = sequelize.define('Eventos', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    title: {
        type: DataTypes.STRING
    },
    date:{
        type: DataTypes.DATE
    },
})


const Materias = sequelize.define('Materias', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    name: {
        type: DataTypes.STRING
    },
})

const Secciones = sequelize.define('Secciones', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    name: {
        type: DataTypes.STRING
    },
})



//relaciones


module.export = {Materias, Secciones, Eventos}