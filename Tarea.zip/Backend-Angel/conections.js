const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('sistema_tarea', 'postgres', 'adminuser', {
    host: 'localhost',
    dialect: 'postgres'
  });

module.exports = sequelize;

