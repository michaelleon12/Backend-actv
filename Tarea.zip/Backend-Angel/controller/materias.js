const Materias = require('../models/materias')

const agregar = async (req, res) => {
    try {
        let data = req.body.name
        const nuvData = await Materias.create({              
            name : data
        })
        return {message: 'Datos editados'} 
    } catch (error) {
        return {message: 'A ocurrido unn error'}
    }    

}

const editar = async (req, res) => {
    try {
        targetId = req.params
        let data = req.body.name
        const resultado = await Profesores.findByPk(targetId)
        resultado.name = data
        await resultado.save()
        return {message: 'Datos editados'} 
    } catch (error) {
        return(error)
    }    
}


module.exports = {agregar, editar};