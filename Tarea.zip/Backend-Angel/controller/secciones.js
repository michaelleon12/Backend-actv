const Secciones = require('../models/secciones');


const agregar = async (req, res) => {
    try {
        let titleData = req.body.title
        let dateData = req.body.date
        const nuvData = await Secciones.create({              
            title : titleData,
            dateData :  dateData
        })
        return {message: 'Datos editados'} 
    } catch (error) {
        return {message: 'A ocurrido unn error'}
    }    

}


module.exports = {agregar}