const Profesores  = require('../models/profesores.js');



const listarPro = async (req, res) => {           
    try {
        const resultado = await Profesores.findAll()
    } catch (error) {
        return(error)
    }    
    
}
            
const agregar = async (req, res) => {
        try {
            console.log(Profesores)
            let data = req.body.name
            const nuvData = await Profesores.create({              
                name : data
            })
            return {message: 'Datos editados'} 
        } catch (error) {
            return {message: 'A ocurrido unn error'}
        }    
    
    }

module.exports = {listarPro, agregar};