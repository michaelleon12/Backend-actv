const Eventos = require('../models/eventos');


const agregar = async (req, res) => {
    try {
        let titleData = req.body.title
        let dateData = req.body.date
        const nuvData = await Eventos.create({              
            title : titleData,
            dateData :  dateData
        })
        return {message: 'Datos editados'} 
    } catch (error) {
        return {message: 'A ocurrido unn error'}
    }    
}


const editar = async (req, res) => {
    try {
        targetId = req.params
        let titleData = req.body.title
        let dateData = req.body.date
        const resultado = await Profesores.findByPk(targetId)
        resultado.title = titleData
        resultado.date = dateData
        await resultado.save()
        return {message: 'Datos editados'} 
    } catch (error) {
        return(error)
    }    
}

model.exports = {agregar, }