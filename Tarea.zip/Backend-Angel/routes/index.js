var express = require('express');
var router = express.Router();
const { eventos, materias, secciones, profesores } = require('../database/database');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.status(400).json({profesores, eventos, materias, secciones});
});

module.exports = router;
