var express = require('express');
var router = express.Router();
const agregar = require('../controller/secciones')

//Agregar
router.post('/', function (req, res, next) {
    res.send(agregar(req, res),).json({"message": message})
});

module.exports = router;