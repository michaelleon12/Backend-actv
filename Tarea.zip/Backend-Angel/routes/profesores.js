var express = require('express');
var router = express.Router();
const {listarPro, agregar} = require('../controller/profesores')

//Agregar
router.post('/', function (req, res, next) {
    res.send(agregar(req, res),).json({"message": message})
});

//listar 
router.get('/', function (req, res, next) {
    res.send(listarPro()) 
});

module.exports = router;
