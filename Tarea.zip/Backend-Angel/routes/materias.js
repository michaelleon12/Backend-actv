var express = require('express');
var router = express.Router();
const { agregar, editar } = require('../controller/materias')

//Agregar
router.post('/', function (req, res, next) {
    res.send(agregar(req, res)).json({"message": message})
});


//Editar
router.put('/:id', function (req, res, next) {
    res.send(editar(req, res, id)).json({"message": message})


//Editar - Asignacion a Profesor
router.put('/asignacion/:id', function (req, res, next) {
    const { id } = req.params

    Materias.editarProfesor(req.body, id)
    .then((resultado) => {
        res.status(200).json({"status": 200, "data": resultado})
    })
    .catch((error) => {
        console.log(error)
        res.status(400).json({"status": 400, "mensaje": error})
    })
});

//Eliminar - Asignacion a Profesor
router.delete('/asignacion/:id', function (req, res, next) {
    const { id } = req.params

    Materias.eliminarProfesor(id)
    .then((resultado) => {
        res.status(200).json({"status": 200, "data": resultado})
    })
    .catch((error) => {
        console.log(error)
        res.status(400).json({"status": 400, "mensaje": error})
    })
});

module.exports = router;
